import { View, Text, StyleSheet, Image, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

export default function ProfileScreen() {
  return (
    <SafeAreaView style={styles.container}>
      <ScrollView>
        <View style={styles.header}>
          <Image
            source={{ uri: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop&crop=faces' }}
            style={styles.profileImage}
          />
          <Text style={styles.name}>John Doe</Text>
          <Text style={styles.bio}>Health & Wellness Enthusiast</Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Health Goals</Text>
          <View style={styles.goalContainer}>
            <View style={styles.goal}>
              <Text style={styles.goalTitle}>Exercise</Text>
              <Text style={styles.goalText}>30 mins daily</Text>
            </View>
            <View style={styles.goal}>
              <Text style={styles.goalTitle}>Sleep</Text>
              <Text style={styles.goalText}>8 hours</Text>
            </View>
            <View style={styles.goal}>
              <Text style={styles.goalTitle}>Water</Text>
              <Text style={styles.goalText}>2L daily</Text>
            </View>
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Health Metrics</Text>
          <View style={styles.metricContainer}>
            <View style={styles.metric}>
              <Text style={styles.metricLabel}>Height</Text>
              <Text style={styles.metricValue}>175 cm</Text>
            </View>
            <View style={styles.metric}>
              <Text style={styles.metricLabel}>Weight</Text>
              <Text style={styles.metricValue}>70 kg</Text>
            </View>
            <View style={styles.metric}>
              <Text style={styles.metricLabel}>Blood Type</Text>
              <Text style={styles.metricValue}>O+</Text>
            </View>
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Medical History</Text>
          <View style={styles.historyItem}>
            <Text style={styles.historyTitle}>Allergies</Text>
            <Text style={styles.historyText}>None reported</Text>
          </View>
          <View style={styles.historyItem}>
            <Text style={styles.historyTitle}>Medications</Text>
            <Text style={styles.historyText}>None current</Text>
          </View>
          <View style={styles.historyItem}>
            <Text style={styles.historyTitle}>Past Surgeries</Text>
            <Text style={styles.historyText}>None reported</Text>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  header: {
    alignItems: 'center',
    padding: 24,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
  },
  profileImage: {
    width: 120,
    height: 120,
    borderRadius: 60,
    marginBottom: 16,
  },
  name: {
    fontSize: 24,
    fontFamily: 'Inter_700Bold',
    color: '#0f172a',
    marginBottom: 4,
  },
  bio: {
    fontSize: 16,
    color: '#64748b',
    fontFamily: 'Inter_400Regular',
  },
  section: {
    padding: 16,
    backgroundColor: '#ffffff',
    marginTop: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontFamily: 'Inter_600SemiBold',
    color: '#0f172a',
    marginBottom: 16,
  },
  goalContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  goal: {
    flex: 1,
    backgroundColor: '#f1f5f9',
    padding: 16,
    borderRadius: 12,
    marginHorizontal: 4,
    alignItems: 'center',
  },
  goalTitle: {
    fontSize: 14,
    color: '#64748b',
    marginBottom: 4,
    fontFamily: 'Inter_400Regular',
  },
  goalText: {
    fontSize: 16,
    color: '#0f172a',
    fontFamily: 'Inter_600SemiBold',
  },
  metricContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  metric: {
    flex: 1,
    alignItems: 'center',
    padding: 12,
  },
  metricLabel: {
    fontSize: 14,
    color: '#64748b',
    marginBottom: 4,
    fontFamily: 'Inter_400Regular',
  },
  metricValue: {
    fontSize: 18,
    color: '#0f172a',
    fontFamily: 'Inter_600SemiBold',
  },
  historyItem: {
    marginBottom: 16,
  },
  historyTitle: {
    fontSize: 16,
    color: '#0f172a',
    marginBottom: 4,
    fontFamily: 'Inter_600SemiBold',
  },
  historyText: {
    fontSize: 16,
    color: '#64748b',
    fontFamily: 'Inter_400Regular',
  },
});